#include <stdio.h>

#include "TicTacToeFunctions.h"



int main() {
    char tBoard[3][3]; /*beginning parts of the game, put in loop so player can restart game at the end*/
    printf("The players will enter their names when prompted and choose their desired symbol, an X or O.\n Each player will take turns choosing a spot on the Tic Tac Toe"
           "grid to place their symbol.\n The first player to place 3 of their symbols in a row, whether diagonally, horizontally, or vertically, wins the game.\n If "
           "the board is full before either player wins, the game ends without a winner. Have fun!\n");
    char p1, p2;
    char p1name[50];
    char p2name[50];
    playerChooseCharacter(&p1, &p2, p1name, p2name);
    char repeat = 'y';

    while(repeat =='y') {
        generateEmptyBoard(tBoard);
        int turn = 0; //if turn is 0 - player 1's turn, else player 2's turn


        while (checkBoardP1(tBoard, p1) == 1 && checkBoardP2(tBoard, p2) == 1 &&
               checkForFullBoard(tBoard) < 9) { //checks board for wins/for a full board
            switch (turn) {
                case 0:
                    if (playPlayer1(tBoard, p1, p1name)) {
                        printBoard(tBoard);
                        turn++;
                    }
                    break;

                case 1:
                    if (playPlayer2(tBoard, p2, p2name)) {
                        printBoard(tBoard);
                        turn--;
                    }
                    break;
            }
        }
        if(checkForFullBoard(tBoard) == 9)
            printf("Tie.");
        else if(!checkBoardP1(tBoard, p1))
            printf("%s wins!!", p1name);
        else
            printf("%s wins!!", p2name);

        while(getchar()!='\n');
        printf("\nWould you like to continue playing? (y/n): ");
        repeat = getchar();
    }
}















