//
// Created by Grace Everts on 7/8/20.
//

#ifndef ASSIGNMENT6_TICTACTOEFUNCTIONS_H
#define ASSIGNMENT6_TICTACTOEFUNCTIONS_H

void printBoard(char[3][3]);
void generateEmptyBoard(char[3][3]);
void playerChooseCharacter(char*, char*, char*, char*);
int checkBoardP1(char arr[3][3], char);
int checkBoardP2(char arr[3][3], char);
int playPlayer1(char arr[3][3], char, char*);
int playPlayer2(char arr[3][3], char, char*);
int checkForFullBoard(char arr[3][3]);
#endif //ASSIGNMENT6_TICTACTOEFUNCTIONS_H
