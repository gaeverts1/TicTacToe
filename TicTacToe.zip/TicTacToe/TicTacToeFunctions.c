#include <stdlib.h>
#include <stdio.h>
#include <string.h>


void printBoard(char arr[3][3]){ //prints the board
    printf("           |           |\n"
           "           |           |\n");
    printf("     %c     |     %c     |      %c      \n", arr[0][0], arr[0][1], arr[0][2]); //prints elements of board array
    printf("           |           |\n"
           "           |           |\n"
           "___________________________________\n"
           "           |           |\n"
           "           |           |\n");
    printf("     %c     |     %c     |      %c      \n", arr[1][0], arr[1][1], arr[1][2]);
    printf("           |           |\n"
           "           |           |\n"
           "___________________________________\n"
           "           |           |\n"
           "           |           |\n");
    printf("     %c     |     %c     |      %c      \n", arr[2][0], arr[2][1], arr[2][2]);
    /*printf("     X     |     O     |      X      \n");*/
    printf("           |           |\n"
           "           |           |\n");
}

void generateEmptyBoard(char arr[3][3]){ //places "." in the empty spaces
    for(int i = 0; i<3; i++){
        for(int j = 0; j<3; j++){
            arr[i][j] = '.';
        }
    }

}

void playerChooseCharacter(char *p1, char *p2, char *p1name, char *p2name){
    printf("Player 1 - Enter your name: "); //choosing names
    fgets(p1name, 50, stdin);
    for(int i = 0; i<50; i++){
        if(p1name[i] == '\n'){
            p1name[i] = '\0';
            break;
        }
    }
    printf("\nPlayer 2 - Enter your name: ");
    fgets(p2name, 50, stdin);
    for(int i = 0; i<50; i++){
        if(p2name[i] == '\n'){
            p2name[i] = '\0';
            break;
        }
    }

    printf("\n%s - choose X or O: ", p1name);//choosing character (p1 gets to choose)
    *p1 = getchar();
    if(*p1 == 'O')
        *p2 = 'X';
    else
        *p2 = 'O';

}

int checkBoardP1(char arr[3][3], char p1){ //returns 0 if P1 has won
    if(arr[0][0] == p1 && arr[0][1] == p1 && arr[0][2] == p1) //horizontal checks
        return 0;
    else if(arr[1][0] == p1 && arr[1][1] == p1 && arr[1][2] == p1)
        return 0;
    else if(arr[2][0] == p1 && arr[2][1] == p1 && arr[2][2] == p1)
        return 0;
    else if(arr[0][0] == p1 && arr[1][0] == p1 && arr[2][0] == p1) //vertical check
        return 0;
    else if(arr[0][1] == p1 && arr[1][1] == p1 && arr[2][1] == p1)
        return 0;
    else if(arr[0][2] == p1 && arr[1][2] == p1 && arr[2][2] == p1)
        return 0;
    else if(arr[0][0] == p1 && arr[1][1] == p1 && arr[2][2] == p1) //diagonal check
        return 0;
    else if(arr[0][2] == p1 && arr[1][1] == p1 && arr[2][0] == p1)
        return 0;
    else
        return 1;
}

int checkBoardP2(char arr[3][3], char p2){ //returns 0 if Y player has won
    if(arr[0][0] == p2 && arr[0][1] == p2 && arr[0][2] == p2) //horizontal checks
        return 0;
    else if(arr[1][0] == p2 && arr[1][1] == p2 && arr[1][2] == p2)
        return 0;
    else if(arr[2][0] == p2 && arr[2][1] == p2 && arr[2][2] == p2)
        return 0;
    else if(arr[0][0] == p2 && arr[1][0] == p2 && arr[2][0] == p2) //vertical check
        return 0;
    else if(arr[0][1] == p2 && arr[1][1] == p2 && arr[2][1] == p2)
        return 0;
    else if(arr[0][2] == p2 && arr[1][2] == p2 && arr[2][2] == p2)
        return 0;
    else if(arr[0][0] == p2 && arr[1][1] == p2 && arr[2][2] == p2) //diagonal check
        return 0;
    else if(arr[0][2] == p2 && arr[1][1] == p2 && arr[2][0] == p2)
        return 0;
    else
        return 1;
}

int playPlayer1(char arr[3][3], char p1, char *p1name){ //return 0 if invalid input
    int p1X, p1Y;
    printf("\n%s - choose x-coordinate (from 1-3): ", p1name);
    scanf("%d", &p1X);
    printf("%s - choose y-coordinate (from 1-3): ", p1name);
    scanf("%d", &p1Y);


    if(arr[p1Y - 1][p1X - 1] == '.') {
        arr[p1Y - 1][p1X - 1] = p1;
        return 1;
    }
    else {
        printf("Invalid input. Try again.\n\n");
        return 0;
    }
}

int playPlayer2(char arr[3][3], char p2, char *p2name){
    int p2X, p2Y;
    printf("\n%s - choose x-coordinate (from 1-3): ", p2name);
    scanf("%d", &p2X);
    printf("%s - choose y-coordinate (from 1-3): ", p2name);
    scanf("%d", &p2Y);


    if(arr[p2Y - 1][p2X - 1] == '.') {
        arr[p2Y - 1][p2X - 1] = p2;
        return 1;
    }
    else {
        printf("Invalid input. Try again.\n\n");
        return 0;
    }
}

int checkForFullBoard(char arr[3][3]){//returns number of full spaces
    int count = 0;
    for(int i = 0; i<3; i++){
        for(int j = 0; j<3; j++){
            if(arr[i][j]=='X' || arr[i][j]=='O')
                count++;
        }
    }
    return count;
}